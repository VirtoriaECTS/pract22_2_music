package com.example.practica22_2


import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var login: EditText
    private lateinit var password: EditText
    private lateinit var regist: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        login=findViewById(R.id.login)
        password=findViewById(R.id.password)
        regist=findViewById(R.id.registerButton)
        sharedPreferences = getSharedPreferences("my_app_prefs", Context.MODE_PRIVATE)
        regist.setOnClickListener{
            val username = login.text.toString().trim()
            val password = password.text.toString().trim()

            if (username.isEmpty()) {
                Snackbar.make(findViewById(android.R.id.content), "Введите логин", Snackbar.LENGTH_SHORT).show()
                if (password.isEmpty()) {
                    Snackbar.make(findViewById(android.R.id.content), "Введите пароль", Snackbar.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                Snackbar.make(findViewById(android.R.id.content), "Введите пароль", Snackbar.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            // сохранение имя пользователя и пароля в SharedPreferences
            sharedPreferences.edit().putString("login", username).apply()
            sharedPreferences.edit().putString("password", password).apply()

            val alertDialogBuilder = AlertDialog.Builder(this)
            alertDialogBuilder.setTitle("Регистрация завершена")
            alertDialogBuilder.setMessage("Вы успешно зарегистрировались.")
            alertDialogBuilder.setPositiveButton("OK") { _, _ ->
                val intent = Intent(this, InfoMusic::class.java)
                startActivity(intent)
                finish()
            }
            val alertDialog = alertDialogBuilder.create()
            alertDialog.show()
        }
    }
}