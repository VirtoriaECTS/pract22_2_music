package com.example.practica22_2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class InfoMusic : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info_music)
    }
    // Функция, которая выполнит запрос для поиска id артиста
    fun searchArtistId(artistName: String, callback: (String) -> Unit) {
        val apiKey = "VbokmShmIcueAGWMQNxFTIwylPfNdEVDHnsqxZWW"
        val searchUrl = "https://api.discogs.com/database/search?q=$artistName&type=artist&token=$apiKey"

        val queue = Volley.newRequestQueue(this)

        val stringRequest = StringRequest(
            Request.Method.GET, searchUrl,
            { response ->
                try {
                    val jsonObject = JSONObject(response)
                    val resultsArray = jsonObject.getJSONArray("results")

                    if (resultsArray.length() > 0) {
                        val artistInfo = resultsArray.getJSONObject(0) // Первый результат
                        val artistId = artistInfo.optInt("id")
                        callback(artistId.toString())
                    } else {
                        callback("") // Если информация о певце не найдена
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                    callback("") // Если произошла ошибка
                }
            },
            {
                Log.d("MyLog", "Volley error: ${it.message}")
                callback("") // Если произошла ошибка
            })

        queue.add(stringRequest)
    }

    // Функция для получения информации об артисте по его id
    private fun getResualt(idArtist: String) {
        if (idArtist.isEmpty()) {
            // Если id артиста не найден, выводим сообщение
            val textInfoSet: TextView = findViewById(R.id.textView)
            textInfoSet.text = "Артист не найден"
        } else {
            val textInfoSet: TextView = findViewById(R.id.textView)
            val url = "https://api.discogs.com/artists/$idArtist?callback=Nirvana"
            val queue = Volley.newRequestQueue(this)

            val stringRequest = StringRequest(
                Request.Method.GET, url,
                { response ->
                    // Обрабатываем JSONP-ответ
                    val jsonpData = response.substring(response.indexOf("(") + 1, response.lastIndexOf(")"))
                    try {
                        val jsonObject = JSONObject(jsonpData)
                        val artistData = jsonObject.getJSONObject("data")
                        val name = artistData.getString("name")
                        val profile = artistData.getString("profile")

                        val artistInfo =
                            "Имя артиста: $name\nПрофиль: $profile"

                        //запись в бд

                        val db = MainDb.getDb(this)
                        val item = Item(null, name.toString(), profile.toString())
                        Thread{
                            db.getDao().insertItem(item)
                        }.start()

                        textInfoSet.text = artistInfo
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                {
                    Log.d("MyLog", "Volley error hetresult: ${it.message}")
                })

            queue.add(stringRequest)
        }
    }
    fun getResualtBut(view: View) {
        val find = findViewById<EditText>(R.id.info_text)
        searchArtistId(find.text.toString()) { id ->
            getResualt(id)
        }
    }
    fun butStatick(view: View) {
        val intent = Intent(this@InfoMusic, ScreenStatistics::class.java)
        startActivity(intent)
    }
}